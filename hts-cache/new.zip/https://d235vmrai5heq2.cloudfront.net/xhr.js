<!DOCTYPE html>
<html>
    <head>
        <title>Page not found</title>
        
        
        
        <style>
            .parrot .text-blue{
                color: #304670;
                letter-spacing: 2px;
            }
            .zenstyle .btn-primary {
                color: #fff;
                background-color: #2f4671;
            }
            .text-center {
                text-align: center;
            }
            .parrot .btn-lg {
                padding: 10px 18px;
                font-size: 20px;
                line-height: 1.45;
                border-radius: 4px;
            }
            .parrot .btn {
                font-family: inherit;
                border: 1px solid transparent;
                font-size: 16px;
                line-height: 1.6;
                border-radius: 4px;
                padding: 7px 15px;
                text-transform: uppercase;
                text-decoration: none;
            }
            .btn {
                display: inline-block;
                padding: 6px 12px;
                margin-bottom: 0;
                font-size: 14px;
                font-weight: inherit;
                line-height: 1.42857143;
                text-align: center;
                white-space: nowrap;
                vertical-align: middle;
                -ms-touch-action: manipulation;
                touch-action: manipulation;
                cursor: pointer;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
                background-image: none;
                border: 1px solid transparent;
                border-radius: 4px;
            }
        </style>

    </head>
    <body class="body-style">
        <div id="page" class="page">
            <div class="block empty" style="background-color: rgb(255, 255, 255);">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12"></div>
                    </div>
                </div>

            </div>
            <div class="block empty parrot zenstyle" style="padding-top: 50px; padding-bottom: 50px; background-color: rgb(255, 255, 255);">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="text-blue text-center" style="font-size: 55px;">Oops...The page could not be found!</div>
                            <div class="text-center" style="max-width: 35%;margin: 0 auto;"><svg xmlns="http://www.w3.org/2000/svg" id="Lineart" viewBox="0 0 1200 1200"><defs><style>.cls-1,.cls-2,.cls-3{fill:none;stroke-linecap:round;}.cls-1,.cls-2{stroke:#000;}.cls-1,.cls-3{stroke-linejoin:round;}.cls-2{stroke-miterlimit:10;}.cls-3{stroke:#949494;stroke-width:2.39px;}</style></defs><title>page not found</title><path class="cls-1" d="M231.76,483.81c-9.9,11.68-17.58,23.73-22.31,35.63"/><path class="cls-1" d="M677.75,477.71c-15.58-13.77-34.39-24.46-51.32-24.46-28.93,0-29.4,15.3-57.59,15.3-43.46,0-75.71-72.66-159.29-72.66-38.9,0-83,15.95-120.36,39.38"/><path class="cls-1" d="M868.18,437.7c-19-12.17-41.19-20-66.3-20-101.27,0-151.3,116.21-217.58,116.21-60.75,0-65.54-30.76-140.74-30.76-32.67,0-88.38,27.91-121.88,65.56"/><path class="cls-1" d="M597.81,685.78a23.31,23.31,0,0,1-.46-6.07c.31-6.47,2.91-11.61,5.81-11.47a3.29,3.29,0,0,1,2.37,1.47"/><path class="cls-2" d="M590.28,737.78c.68-8.45,4.62-41.72,7.83-53.15"/><path d="M542.87,805V999.88H559l18.54-104.26S580.09,839.22,542.87,805Z"/><path d="M596,801.16c.45,5.62,6.06,107.88,6.06,107.88v93.11l-16.55,1.77-10.64-99-32-99.92C547.71,802.34,583.16,797.33,596,801.16Z"/><path class="cls-2" d="M595,758.46c3.49,20.18,2.9,40.35,1.07,42.7-3.79,4.87-49,8.17-53.16,3.83-3.76-3.93-13.76-73.83,13.56-87.29"/><path class="cls-2" d="M568.84,715.62c9.64,1.26,16.27,10.3,20.71,22.07"/><path class="cls-2" d="M603.86,688.32a20.65,20.65,0,0,1-1.24-8.61c.31-6.47,2.91-11.61,5.81-11.47s5,5.5,4.67,12a21,21,0,0,1-1.87,8.08"/><rect x="585.55" y="681.34" width="3.86" height="3.86" transform="translate(-98.87 99.39) rotate(-8.92)"/><path class="cls-1" d="M568.84,708.22v7.25"/><path class="cls-1" d="M566.39,724.19c-3.62.89-10,.43-10-1.69V696"/><path class="cls-2" d="M579.59,678a28,28,0,0,1,1.9,10.34c0,11-5.83,19.9-13,19.9a9.69,9.69,0,0,1-6.15-2.35"/><path class="cls-1" d="M557.88,695.82a4.37,4.37,0,0,1-1.21.17,4.33,4.33,0,1,1,2.19-8.06"/><rect x="512.81" y="718.34" width="25.14" height="84.61" rx="12.57" ry="12.57"/><path class="cls-2" d="M574.77,757.17c-2.58,15.34-15,27-29.88,27-16.78,0-30.38-14.73-30.38-32.89s13.6-32.9,30.38-32.9a29.5,29.5,0,0,1,23.44,12"/><path class="cls-1" d="M581,737c4.94.26,12.6.92,16.33,2.26.4-2.53,2.66-38.77,6.51-50.91"/><path class="cls-1" d="M611.28,688.32c0,1.44,8.51,60.88,0,67.93-6.67,5.52-25.85.91-34.4-1.78"/><path class="cls-2" d="M549.66,734.69c2.82-11.48,28.36-1.93,30.67.69,2.77,3.14-2.18,20.84-6,21.66C568.1,758.39,546,749.58,549.66,734.69Z"/><polyline class="cls-2" points="325.88 849.68 390.13 849.68 266.38 341.65 215.98 548.57"/><polyline class="cls-2" points="257.61 734.34 169.62 341.65 45.87 893.9 197.6 893.9"/><line class="cls-3" x1="170.29" y1="891.44" x2="170.29" y2="395.36"/><line class="cls-3" x1="170.29" y1="558.95" x2="197.18" y2="529.72"/><line class="cls-3" x1="170.29" y1="698.94" x2="210.7" y2="655.02"/><line class="cls-3" x1="170.29" y1="844.98" x2="190.01" y2="823.55"/><line class="cls-3" x1="170.29" y1="558.95" x2="143.4" y2="529.72"/><line class="cls-3" x1="170.29" y1="698.94" x2="129.89" y2="655.02"/><line class="cls-3" x1="170.29" y1="844.98" x2="107.44" y2="776.66"/><rect class="cls-3" x="190.5" y="734.34" width="135.39" height="197.16" rx="67.69" ry="67.69"/><line class="cls-3" x1="258.19" y1="982.94" x2="258.19" y2="795.85"/><path class="cls-3" d="M258.19,875.41c37,0,37-22.28,37-56"/><path class="cls-3" d="M258.19,841.33c-25.65,0-25.65-15.47-25.65-38.84"/><path class="cls-1" d="M750.87,849.68h91.86"/><path class="cls-1" d="M921.38,849.68h231V667.57a81.52,81.52,0,0,0-81.28-81.28h0a81.65,81.65,0,0,0-13.07,1.06V377.78a55.64,55.64,0,0,0-55.63-55.64h0a55.64,55.64,0,0,0-55.64,55.64v44.86a80.64,80.64,0,0,0-26-4.31h0a81.52,81.52,0,0,0-81.28,81.29V649H804.08a55.7,55.7,0,0,0-55.53,55.53V833.86a55.18,55.18,0,0,0,2.32,15.82"/><path class="cls-3" d="M1000.16,740.85c91.61,0,91.61-41,91.61-103"/><path class="cls-3" d="M1000.25,795.48c-50.4,0-50.4-22.56-50.4-56.67"/><line class="cls-3" x1="1000.16" y1="849.68" x2="1000.16" y2="364.17"/><line class="cls-3" x1="1000.16" y1="637.85" x2="949.94" y2="587.62"/><line class="cls-3" x1="1000.16" y1="534.21" x2="1030.55" y2="503.83"/><path class="cls-1" d="M750.49,341.65a47.18,47.18,0,0,0-86.25-35.55,37.43,37.43,0,0,0-52.84,34.1c0,.49,0,1,0,1.45Z"/><path class="cls-1" d="M291.91,268.28a47.18,47.18,0,0,1,86.25-35.55A37.4,37.4,0,0,1,431,266.83c0,.48,0,1,0,1.45Z"/><path class="cls-1" d="M1014.14,976.15c-7.13-22.74-44.63-40.09-89.81-40.09-50.28,0-91,21.47-91,48H996.67"/><path class="cls-1" d="M502.76,1006.93c-12.55,0-22.73,8.76-22.73,19.57H525.5C525.5,1015.69,515.32,1006.93,502.76,1006.93Z"/><path class="cls-1" d="M833.3,902.44c-12.56,0-22.73,13-22.73,29.06H856C856,915.45,845.85,902.44,833.3,902.44Z"/><path class="cls-1" d="M120.87,974.57c-20,0-36.16,6.51-36.16,14.53H157C157,981.08,140.84,974.57,120.87,974.57Z"/><path class="cls-1" d="M1030.55,974.57c-20,0-36.16,6.51-36.16,14.53h72.31C1066.7,981.08,1050.52,974.57,1030.55,974.57Z"/><rect class="cls-1" x="838.22" y="746.55" width="87.67" height="127.66" rx="43.83" ry="43.83"/><line class="cls-3" x1="882.06" y1="907.53" x2="882.06" y2="786.38"/><path class="cls-3" d="M882.06,837.9C906,837.9,906,823.47,906,801.64"/><path class="cls-3" d="M882.06,815.83c-16.61,0-16.61-10-16.61-25.16"/><line class="cls-3" x1="331.71" y1="947.65" x2="412.75" y2="947.65"/><line class="cls-3" x1="668.4" y1="893.9" x2="722.14" y2="893.9"/><line class="cls-3" x1="627.87" y1="907.53" x2="681.62" y2="907.53"/><line class="cls-3" x1="116.88" y1="918.64" x2="170.63" y2="918.64"/><line class="cls-3" x1="748.55" y1="999.24" x2="824.1" y2="999.24"/><path class="cls-2" d="M552.29,685.27c-2.08-1.68-2.32-14,2.93-18.21s20.6-7.5,27.26-13.23"/><path class="cls-2" d="M578,665.13c1.53-1.31,6.34-8.81,7.15-10.83"/><path class="cls-2" d="M582.55,667.88a21.93,21.93,0,0,0,3.46-8"/><path d="M613.1,680.22a25,25,0,0,1-.52,4l8.12-.67-2.18-13.19-6.36,2A21.88,21.88,0,0,1,613.1,680.22Z"/><path d="M602.62,679.71a25.59,25.59,0,0,1,.62-4.49l-15,4.74,1,6.22,13.68-1.13A24,24,0,0,1,602.62,679.71Z"/><polyline class="cls-1" points="544.3 999.88 544.3 1022.54 576.61 1022.54 553.54 1008.18 553.54 999.13"/><polyline class="cls-1" points="588.78 999.88 588.78 1022.54 621.09 1022.54 598.01 1008.18 598.01 999.13"/><path class="cls-2" d="M574.07,685.27c0,1.19.54,4.92,3.09,6.83"/><path class="cls-2" d="M570.54,695.39a3.49,3.49,0,0,0,3.14,1.86"/></svg></div>
                            <div class="text-center">
                                <a href="/" class="dynamic btn btn-primary btn-lg">Back to home</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </body>
</html>
